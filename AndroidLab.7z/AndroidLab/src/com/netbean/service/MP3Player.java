package com.netbean.service;

import android.app.IntentService;
import android.content.Intent;

public class MP3Player extends IntentService {

	public MP3Player(String name)
	{
		super(name);
		// TODO Auto-generated constructor stub
	}

	@Override
	protected void onHandleIntent(Intent intent)
	{
		// TODO Auto-generated method stub

	}

}
