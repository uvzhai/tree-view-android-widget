/**
 * Copyright (C) 2011 Tencent Inc.
 * All rights reserved, for internal usage only.
 * 
 * Project: SosoClient
 * FileName: RegexUtils.java
 * 
 * Description: The class provides the implementation for RegexUtils.
 * Author: lorenchen (lorenchen@tencent.com)
 * Created: September 12, 2011
 */

package com.netbean.utils;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RegexUtils {

	/**
	 * @param source
	 * @param regex
	 * @return first matched result
	 */
	public static String extract(String source , String regex ,int groupID)
	{
		String result = null;
		Pattern pattern = Pattern.compile(regex);
		Matcher matcher = pattern.matcher(source);
		if(matcher.find()){
			result = matcher.group(groupID);
		}
		return result;
	}
	
	/**
	 * �õ���ҳ��ͼƬ�ĵ�ַ
	 */
	public static List<String> getImgStr(String htmlStr)
	{
		String img = "";
		Pattern p_image;
		Matcher m_image;
		List<String> pics = new ArrayList<String>();

		String regEx_img = "<img.*src=(.*?)[^>]*?>"; // ͼƬ���ӵ�ַ
		p_image = Pattern.compile(regEx_img, Pattern.CASE_INSENSITIVE);
		m_image = p_image.matcher(htmlStr);
		while (m_image.find())
		{
			img = img + "," + m_image.group();
			Matcher m = Pattern.compile("src=\"?(.*?)(\"|>|\\s+)").matcher(img); // ƥ��src
			while (m.find())
			{
				pics.add(m.group(1));
			}
		}
		return pics;
	}
}
