package com.netbean.view;

import java.io.InputStream;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.PointF;
import android.graphics.Rect;
import android.graphics.RectF;
import android.os.SystemClock;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.LinearInterpolator;
import android.view.animation.Transformation;
import android.view.animation.TranslateAnimation;

import com.netbean.lab.R;

public class AnimView2 extends View {

	public AnimView2(Context context)
	{
		super(context);

		Resources re = this.getResources();
		InputStream is = re.openRawResource(R.drawable.ic_launcher);
		mBitmap = BitmapFactory.decodeStream(is);
		mSrcRect = new Rect();

		init();
		mDstRectF = new RectF(mEndPoint.x, mEndPoint.y, mEndPoint.x + mBitmap.getWidth(), mEndPoint.y
				+ mBitmap.getHeight());

		mPaint = new Paint();
		mPaint.setColor(Color.WHITE);
		mPaint.setAntiAlias(true);
	}

	@Override
	protected void onDraw(Canvas canvas)
	{
		long curTime = SystemClock.uptimeMillis();

		if (mCurrentAnimation == null)
		{
			//canvas.drawBitmap(mBitmap, null, mDstRectF, null);
			//canvas.drawBitmap(mBitmap, mTransformation.getMatrix(), null);
			
			//Matrix m = canvas.getMatrix();

			// new matrix
			Matrix newM = mTransformation.getMatrix();
			canvas.setMatrix(newM);

			canvas.drawBitmap(mBitmap, newM, null);
			//canvas.setMatrix(m);
		}
		else
		{
			if (!mCurrentAnimation.isInitialized()) // initialize animation

				mCurrentAnimation.initialize(50, 50, 50, 50);

			boolean more = mCurrentAnimation.getTransformation(curTime, mTransformation);

			if (more)
			{
				Matrix m = canvas.getMatrix();

				// new matrix
				Matrix newM = mTransformation.getMatrix();
				canvas.setMatrix(newM);

				canvas.drawBitmap(mBitmap, newM, null);
				// canvas.drawBitmap(mBitmap, null, mDstRectF, null);

				canvas.setMatrix(m);

				this.invalidate();
			}
			else
			{
				mCurrentAnimation = null;
				this.invalidate();
			}
		}
	}

	public void startAnimation(Animation animation)
	{
		animation.setStartTime(Animation.START_ON_FIRST_FRAME);
		setAnimation(animation);
		invalidate();
	}

	@Override
	public void setAnimation(Animation animation)
	{
		mCurrentAnimation = animation;
		if (animation != null)
		{
			animation.reset();
		}
	}

	private void init()
	{
		mStartPoint = new PointF(0, 0);
		mEndPoint = new PointF(100, 100);
		Animation anim = new TranslateAnimation(0, mEndPoint.x - mStartPoint.x, 0, mEndPoint.y - mStartPoint.y);

		anim.setDuration(2000); // 2s
		
		//Interpolator aPolator = new LinearInterpolator();
		
		anim.setInterpolator(new LinearInterpolator());

		anim.setFillAfter(true);

		startAnimation(anim);
	}

	Animation mCurrentAnimation = null;
	Transformation mTransformation = new Transformation();
	PointF mStartPoint;
	PointF mEndPoint;

	Bitmap mBitmap;
	Rect mSrcRect;
	RectF mDstRectF;
	Paint mPaint;
}
