/**
 * Copyright (C) 2012 Tencent Inc.
 * All rights reserved, for internal usage only.
 * 
 * Project: SosoNovel
 * FileName: NovelAdapter.java
 * 
 * Description: 
 * Author: xingyao (xingyao@tencent.com)
 * Created: 2012-3-8
 */
package com.netbean.view;

import java.util.ArrayList;
import java.util.List;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;

/**
 * 
*   
* Class Name:RadioAdapter 
* Class Description: 
* Author: xingyao 
* Modify: xingyao 
* Modify Date: 2012-3-8 ����06:28:55 
* Modify Remarks: 
* @version 1.0.0
*
 */
public class RadioAdapter extends BaseAdapter
{
	protected LayoutInflater mInflater;
	protected List<String> mList;
	protected Context      mContext;
	protected int          mPickIdx;
		
	/**
	 * 
	* Create a new Instance ChapterAdapter.  
	*
	*/
	public RadioAdapter(Context aContext)
	{
		mList = new ArrayList<String>();
		mContext = aContext;
		mInflater = (LayoutInflater)mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		mPickIdx = 0;
	}
		
	/**
	 * 
	* method Name:setList    
	* method Description:  
	* @param aList   
	* void  
	* @exception   
	* @since  1.0.0
	 */
	public void setList(List<String> aList)
	{
		mList.clear();
		if(null!=aList)
			mList.addAll(aList);
	}
	
	/**
	 * 
	* method Name:setPickIdx    
	* method Description:  
	* @param aIndex   
	* void  
	* @exception   
	* @since  1.0.0
	 */
	public void setPickIdx(int aIndex)
	{
		mPickIdx = aIndex;
	}
	/*  
	 * Description:
	 * @see android.widget.Adapter#getCount()
	 */
	@Override
	public int getCount() {
		return (null==mList) ? 0 : mList.size();
	}

	/*  
	 * Description:
	 * @see android.widget.Adapter#getItem(int)
	 */
	@Override
	public Object getItem(int position) {
		return (null==mList) ? null : mList.get(position);
	}

	/*  
	 * Description:
	 * @see android.widget.Adapter#getItemId(int)
	 */
	@Override
	public long getItemId(int position) {
		return position;
	}

	/*  
	 * Description:
	 * @see android.widget.Adapter#getView(int, android.view.View, android.view.ViewGroup)
	 */
	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		//todo!!
		return null;
	}
}