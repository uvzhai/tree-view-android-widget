package com.netbean.view;

import java.util.Random;

import android.R;
import android.content.Context;
import android.graphics.Color;
import android.graphics.Point;
import android.graphics.PointF;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.view.MotionEvent;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.Interpolator;
import android.view.animation.LinearInterpolator;
import android.view.animation.TranslateAnimation;
import android.widget.TextView;

public class CloudView extends ViewGroup {
	
	public CloudView(Context context, AttributeSet attrs)
	{
		super(context,attrs);
		
		//init
		mChildViews = new TextView[mCount];
		
		
		mLayoutParams  = new LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT);
		addChildViews(context);
	}
	
	public void setDisplayMetrics(DisplayMetrics dm)
	{
		mDisplayMetrics = dm;
	}
	
	private void initDestPoints()
	{
		int width = mDisplayMetrics.widthPixels;
		int height = mDisplayMetrics.heightPixels;
		
		mDestPoints[0] = new Point(0,0);
		mDestPoints[1] = new Point(width,0);
		mDestPoints[2] = new Point(width/2,height/2);
		mDestPoints[3] = new Point(0,height);
		mDestPoints[4] = new Point(width,height);
	}
	
	/*  
	 * Description:
	 * @see android.view.View#onMeasure(int, int)
	 */
	@Override
	protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
		super.onMeasure(widthMeasureSpec, heightMeasureSpec);
		
		final int count = getChildCount();
        for (int i = 0; i < count; i++) {
            getChildAt(i).measure(widthMeasureSpec, heightMeasureSpec);
        }
	}
	
	@Override
	protected void onLayout(boolean changed, int l, int t, int r, int b)
	{
		for(int nIndex = 0; nIndex < this.getChildCount(); nIndex++)
		{
			TextView aAnim = (TextView) this.getChildAt(nIndex);
			int[] postion = mSourcePostions[nIndex];
			aAnim.layout(postion[0], postion[1], postion[2], postion[3]);
		}
	}
	
	private Animation getAnim(PointF endPoint, PointF startPoint)
	{
		Animation result = new TranslateAnimation(0, endPoint.x - startPoint.x, 0, endPoint.y - startPoint.y);
		
		result.setStartTime(Animation.START_ON_FIRST_FRAME);
		
		result.setDuration(1000); // 1s

		Interpolator aPolator = new LinearInterpolator();

		result.setInterpolator(aPolator);

		result.setFillAfter(true);
		return result;
	}
	
	private void addChildViews(Context aContext)
	{
		for(int nIdx=0; nIdx < mChildViews.length;nIdx++)
		{
			TextView aChild = new TextView(aContext);
			aChild.setText(texts[nIdx]);
			aChild.setTextColor(mColors[mRandom.nextInt(mColors.length)]);
			aChild.setTextSize((float) 18.0);
			aChild.setPadding(10, 10, 10, 10);
			aChild.setBackgroundColor(mBasicColor[mRandom.nextInt(mBasicColor.length)]);
			mChildViews[nIdx] = aChild;
			this.addView(aChild,nIdx,mLayoutParams);
		}
	}
	
	
	@Override
	public boolean onTouchEvent(MotionEvent event)
	{
		boolean bHandled = false;
		if(event.getAction() == MotionEvent.ACTION_DOWN)
		{
			// 1. clear UI
			this.removeAllViews();
			
			// 2. fetch random hot words
			// 3. add child views (set random text color)
			this.addChildViews(getContext());
			
			// 4. animation
			for(int nIndex = 0; nIndex < this.getChildCount(); nIndex++)
			{
				TextView aAnim = (TextView) this.getChildAt(nIndex);
				int[] destPostion = mDestPostions[nIndex];
				PointF endPoint = new PointF(destPostion[0], destPostion[1]);
				int[] sourcePostion = mSourcePostions[nIndex];
				PointF startPoint = new PointF(sourcePostion[0],sourcePostion[1]);
				Animation animation = getAnim(endPoint,startPoint);
				aAnim.startAnimation(animation);
			}
			bHandled = true;
		}
		return bHandled;
	}
	
	int[]  mColors = {R.color.white,com.netbean.lab.R.color.red,com.netbean.lab.R.color.green,com.netbean.lab.R.color.blue};
	int[]  mBasicColor = {Color.RED,Color.GREEN,Color.BLUE,Color.YELLOW,Color.MAGENTA};
	Random mRandom = new Random();
	private  int 			 mCount = 5;
	private  TextView[]  mChildViews;
	LayoutParams mLayoutParams;
	PointF 	 mStartPoint;
	PointF   mEndPoint;
	
	DisplayMetrics mDisplayMetrics;
	
	// text
	private String[] texts = {"shanghai","beijing","shenzhen","hefei","xizang"};
	
	private int[][] mSourcePostions = 
		{
			{100,100,150,150},
			{100,100,150,150},
			{100,100,150,150},
			{100,100,150,150},
			{100,100,150,150}
		};
	// (left top point:x,y)  (right bottom point:x,y)
	private  int[][] mDestPostions = 
		{
			{0,0,50,50},
			{150,0,200,50},
			{100,100,150,150},
			{0,200,50,250},
			{150,200,200,250}
		};
	
	private Point[] mDestPoints = new Point[5];
	
	private class Point
	{
		public int x;
		public int y;
		
		public Point(int a, int b)
		{
			x = a;
			y = b;
		}
	}
}
