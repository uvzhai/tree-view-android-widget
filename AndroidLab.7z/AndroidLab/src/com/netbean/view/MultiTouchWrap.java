/**
 * Copyright (C) 2011 Tencent Inc.
 * All rights reserved, for internal usage only.
 * 
 * Project: Soso_Client
 * FileName: MultiTouchWrap.java
 * 
 * Description: 
 * Author: oopsli (oopsli@tencent.com)
 * Created: 2011-12-14
 */
package com.netbean.view;

import android.view.MotionEvent;

/**
 * The Class MultiTouchWrap. !!!!ONLY !!!use this class if sdkVersion >= 5.
 */
public abstract class MultiTouchWrap {
    
    /**
     * Gets the pointer count.
     *
     * @param event the event
     * @return the pointer count
     */
    static int getPointerCount(MotionEvent event) {
        return event.getPointerCount();
    }

    /**
     * Gets the x.
     *
     * @param event the event
     * @param pointerIndex the pointer index
     * @return the x
     */
    static float getX(MotionEvent event, int pointerIndex){
    	return event.getX(pointerIndex);
    }
    
    /**
     * Gets the y.
     *
     * @param event the event
     * @param pointerIndex the pointer index
     * @return the y
     */
    static float getY(MotionEvent event, int pointerIndex){
    	return event.getY(pointerIndex);
    }
}
