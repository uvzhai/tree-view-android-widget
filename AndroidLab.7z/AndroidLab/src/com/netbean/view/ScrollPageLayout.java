/**
 * Copyright (C) 2011 Tencent Inc.
 * All rights reserved, for internal usage only.
 * 
 * Project: Soso_Client
 * FileName: ScrollPageLayout.java
 * 
 * Description: 
 * Author: oopsli (oopsli@tencent.com)
 * Created: 2011-10-11
 */
package com.netbean.view;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.FrameLayout;

/**
 * The Class ScrollPageLayout.
 */
public class ScrollPageLayout extends BaseHorizontalScrollView {

	/**
	 * Instantiates a new scroll page layout.
	 *
	 * @param context the context
	 * @param attrs the attrs
	 */
	public ScrollPageLayout(Context context, AttributeSet attrs) {
		super(context, attrs);
		//disable auto snap to be sticky.
		super.setSnapOnLayout(false);
		//snap factor.
		super.setSnapFactor(0.1f);
		initViews(context, attrs);
	}

	
	/**
	 * Inits the views.
	 *
	 * @param context the context
	 * @param attrs the attrs
	 */
	private void initViews(Context context, AttributeSet attrs) {
		// TODO add views here.
	}
	
	/**
	 * method Name:addFullWidthChild
	 * method Description:  child should have the same width as ScrollPageLayout itself
	 * to help scroll.
	 * void
	 *
	 * @param child the child
	 * @since  1.0.0
	 */
	public void addFullWidthChild(FrameLayout child ){
		if(child != null){
			addView(child);
		}
	}
	
	/**
	 * Gets the total page.
	 *
	 * @return the total page
	 */
	public int getTotalPage(){
		return super.getChildCount();
	}
	
	/**
	 * Scroll to page.
	 *
	 * @param page the page
	 */
	public void scrollToPage(int page){
		super.snapToScreen(page);
	}
	
	public int getCurPage(){
		return super.mCurrentScreen;
	}
	
	@Override
	protected void onSnap(int whichScreen) {
		super.onSnap(whichScreen);
	}
}
