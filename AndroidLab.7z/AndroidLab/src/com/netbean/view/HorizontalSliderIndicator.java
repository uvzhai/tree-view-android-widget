/**
 * Copyright (C) 2011 Tencent Inc.
 * All rights reserved, for internal usage only.
 * 
 * Project: Soso_Client
 * FileName: VerticalSliderIndicator.java
 * 
 * Description: 
 * Author: oopsli (oopsli@tencent.com)
 * Created: 2011-10-11
 */
package com.netbean.view;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.View;

/**
 * The Class VerticalSliderIndicator.
 */
public class HorizontalSliderIndicator extends View{

	/**
	 * Instantiates a new vertical slider indicator.
	 *
	 * @param context the context
	 * @param attrs the attrs
	 */
	public HorizontalSliderIndicator(Context context, AttributeSet attrs) {
		super(context, attrs);
		mPaint=new Paint();
		mPaint.setColor(INDICATOR_DEFAULT_COLOR);
		mRect=new RectF(0, 0, INDICATOR_WIDTH, INDICATOR_HEIGHT);
		setVisibility(View.INVISIBLE);
	}
	
	/**
	* method Name:setPaintColor    
	* method Description:  
	* @param nColor   
	* void  
	* @exception   
	* @since  1.0.0
	 */
	public void setPaintColor(int nColor)
	{
		if(null != mPaint)
		{
			mPaint.setColor(nColor);
		}
	}

	/*  
	 * Description:
	 * @see android.view.View#draw(android.graphics.Canvas)
	 */
	@Override
	public void draw(Canvas canvas) {
		canvas.drawRoundRect(mRect, 2, 2, mPaint);
	}
	
	/**
	 * Sets the total.
	 *
	 * @param total the new total
	 */
	public void setTotal(int total){
		//update width
		final int width = getWidth();
		final int height = getHeight();
		if(width >= 0){
			mWidth = width/total;
			mRect.right =mRect.left + mWidth;
			mRect.bottom = height;
			postInvalidate();
			show();
		}
	}
	
	/**
	 * Show.
	 */
	public void show(){
		this.setVisibility(View.VISIBLE);
	}
	
	/**
	 * Hide.
	 */
	public void hide(){
		this.setVisibility(View.INVISIBLE);
	}
	
	/**
	 * Sets the percent.
	 *
	 * @param percent the new percent
	 */
	public void setPercent(float percent){
		//Log.d(TAG, "percent: "+percent);
		int range = getWidth() - mWidth;
		int offset = (int) ((float)((float)(range)*100*percent)/100);
		mRect.left = offset;
		mRect.right =mRect.left+mWidth;
		//mRect.bottom = getHeight();
		postInvalidate();
	}
	
	/** The Constant INDICATOR_HEIGHT. */
	public static final int INDICATOR_HEIGHT=5;
	
	/** The Constant INDICATOR_WIDTH. */
	public static final int INDICATOR_WIDTH=40;
	
	/** The Constant INDICATOR_DEFAULT_COLOR. */
	private static final int INDICATOR_DEFAULT_COLOR=0xff2073b8;
	
	/** The m rect. */
	private RectF mRect;
	
	/** The m paint. */
	private Paint mPaint;
	
	@SuppressWarnings("unused")
	private static final String TAG = "HorizentalSliderIndicator"; 
	
	private int mWidth = INDICATOR_WIDTH;
	
}
