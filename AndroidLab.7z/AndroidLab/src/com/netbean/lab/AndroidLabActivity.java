package com.netbean.lab;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.Bitmap.Config;
import android.graphics.Canvas;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.drawable.AnimationDrawable;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageView;

import com.netbean.view.AnimView;

public class AndroidLabActivity extends Activity implements OnClickListener {
	
	
	/** Called when the activity is first created. */
	@Override
	public void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		View aView = new AnimView(this);
		setContentView(aView);
		// View aView = new AnalogClock(this);
//		View aView = new ImageView(this);
//
//		Resources re = this.getResources();
//		InputStream is = re.openRawResource(R.drawable.ic_launcher);
//		Bitmap bm = BitmapFactory.decodeStream(is);
//		//Bitmap result = processBitmap(bm);
//		Bitmap result = transferBitmap(bm);
//
//		BitmapDrawable bmDrawable = new BitmapDrawable(result);
//		aView.setBackgroundDrawable(bmDrawable);
//		//setContentView(aView);
//		setContentView(R.layout.main);
//		mImageView = (ImageView) this.findViewById(R.id.image);
//		mImageView.setBackgroundResource(R.drawable.frame_animation);
//		
//		mAnimDrawable = (AnimationDrawable) mImageView.getBackground();
//		mBtn = (Button) this.findViewById(R.id.btn);
//		mBtn.setOnClickListener(this);
	}
	
	@Override
	public void onClick(View v)
	{
		Button aBtn = (Button)v;
		if(aBtn.getText().equals("start"))
		{
			mAnimDrawable.start();
			aBtn.setText("stop");
		}
		else
		{
			mAnimDrawable.stop();
			aBtn.setText("start");
		}
	}
	
	private ImageView    mImageView;
	private AnimationDrawable mAnimDrawable;
	private Button mBtn;

	// set image yellow
	public Bitmap processBitmap(final Bitmap bm)
    {
    	Bitmap output = Bitmap.createBitmap(bm.getWidth(), bm.getHeight(), Config.RGB_565);
    	Canvas aCanvas = new Canvas(output);
    	
    	Paint aPaint = new Paint();
    	
    	// 4*5 color matrix
    	ColorMatrix cm = new ColorMatrix();
    	float[] array = {1,0,0,0,100,
    					 0,1,0,0,100,
    					 0,0,1,0,0,
    					 0,0,0,1,0
    					 };
    	cm.set(array);
    	aPaint.setColorFilter(new ColorMatrixColorFilter(cm));
    	aCanvas.drawBitmap(bm, 0, 0, aPaint);
    	return output;
    }
	
	private Bitmap transferBitmap(final Bitmap bm)
	{
		Bitmap output = Bitmap.createBitmap(bm.getWidth(), bm.getHeight(), Config.RGB_565);
		Canvas aCanvas = new Canvas(output);
		Paint aPaint = new Paint();
		
		// 3*3 coordinates transform matrix
		Matrix matrix = new Matrix();
		float[] array = {
				1,0,50,
				0,1,50,
				0,0,1
		};
		matrix.setValues(array);
		aCanvas.drawBitmap(bm, matrix, aPaint);
		return output;
	}

	@Override
	public void onAttachedToWindow()
	{
		// TODO Auto-generated method stub
		super.onAttachedToWindow();
	}

	@Override
	public void onDetachedFromWindow()
	{
		// TODO Auto-generated method stub
		super.onDetachedFromWindow();
	}

}