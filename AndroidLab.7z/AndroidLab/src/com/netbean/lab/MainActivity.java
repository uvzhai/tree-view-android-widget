package com.netbean.lab;

import android.app.Activity;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends Activity {
	
	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(new Panel(this));
	}
	
	class Panel extends View
	{
		public Panel(Context context)
		{
			super(context);
		}
		
		@Override
		protected void onDraw(Canvas canvas)
		{
//			super.onDraw(canvas);
//			Bitmap bitmap = BitmapFactory.decodeResource(getResources(), R.drawable.koala);
//			canvas.drawColor(Color.WHITE);
//			canvas.drawBitmap(bitmap, 0, 0, null);
		}
	}
}
