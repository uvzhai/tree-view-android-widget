package com.netbean.lab;

import java.net.URL;
import java.util.List;

import android.graphics.Bitmap;
import android.os.AsyncTask;

public class WorkerUtils {


	private void loadData()
	{
		new AsyncTask<Object, Integer, List<Bitmap>>() {

			@Override
			protected List<Bitmap> doInBackground(Object... params)
			{
				for(Object obj : params)
				{
					
				}
				return null;
			}

			protected void onPostExecute(List<Bitmap> result)
			{
				
			};

		}.execute(new Object());
	}

	private class DownloadFilesTask extends AsyncTask<URL, Integer, Long> 
	{
		protected Long doInBackground(URL... urls)
		{
			int count = urls.length;
			long totalSize = 0;
			for (int i = 0; i < count; i++)
			{
				// totalSize += Downloader.downloadFile(urls[i]);
				publishProgress((int) ((i / (float) count) * 100));
			}
			return totalSize;
		}

		protected void onProgressUpdate(Integer... progress)
		{
			//setProgressPercent(progress[0]);
		}

		protected void onPostExecute(Long result)
		{
			// showDialog("Downloaded " + result + " bytes");
		}
	}

}
