package com.netbean.lab;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.PointF;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.view.animation.Animation;
import android.view.animation.TranslateAnimation;
import android.widget.AbsoluteLayout;
import android.widget.TextView;

public class Main extends Activity implements OnTouchListener {

	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.labelslayout);
		init();
	}
	
	private void init()
	{
		mAnim = new TranslateAnimation(0, mEndPoint.x - mStartPoint.x, 0, mEndPoint.y - mStartPoint.y);
		mAnim.setFillAfter(true);
		mAnim.setDuration(4000);
		
		mLabelsLayout = (AbsoluteLayout) this.findViewById(R.id.labelslayout);
		for(String label: labels)
		{
			TextView aTextView = new TextView(this);
			aTextView.setText(label);
			aTextView.setTextSize(20);
			aTextView.setTextColor(Color.RED);
			
			//mStartPoint = new PointF(0, 0);
			//mEndPoint = new PointF(100, 100);
			//Animation mAnim = new TranslateAnimation(0, mEndPoint.x - mStartPoint.x, 0, mEndPoint.y - mStartPoint.y);
			//aTextView.setAnimation(mAnim);
			mLabelsLayout.addView(aTextView);
		}
		mLabelsLayout.setOnTouchListener(this);
	}
	
	@Override
	public boolean onTouch(View v, MotionEvent event)
	{
		int nCount = mLabelsLayout.getChildCount();
		for(int index=0;index<nCount;index++)
		{
			View aChildView = mLabelsLayout.getChildAt(index);
			aChildView.startAnimation(mAnim);
		}
		//mLabelsLayout.invalidate();
		return false;
	}
	
	private AbsoluteLayout mLabelsLayout;
	private TextView mCurrentLabelV;
	
	//data
	private String[] labels = {"qq"};//,"weixin","novel","path","facebook"};
	
	private PointF mStartPoint = new PointF(0, 0);
	private PointF mEndPoint = new PointF(100, 100);
	private Animation mAnim = new TranslateAnimation(0, mEndPoint.x - mStartPoint.x, 0, mEndPoint.y - mStartPoint.y);
}
