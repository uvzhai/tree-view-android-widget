package com.netbean.lab;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.Display;

import com.netbean.view.CloudView;

public class TestViewGroup extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);

		// mCloudV = new CloudView(this, null);
		// this.setContentView(mCloudV,new
		// LayoutParams(LayoutParams.FILL_PARENT, LayoutParams.FILL_PARENT));
		this.setContentView(R.layout.cloudlayout);
		mCloudV = (CloudView) this.findViewById(R.id.cloudview);
		// set display metrics
		DisplayMetrics aMetrics = new DisplayMetrics();
		initMetrics(aMetrics);
		mCloudV.setDisplayMetrics(aMetrics);
		// ActivityManager
		// Debug.dumpHprofData(fileName);
	}

	protected void initMetrics(DisplayMetrics pMetrics)
	{
		if (null == pMetrics)
		{
			return;
		}

		// Get default display.
		Display pDisplay = getWindowManager().getDefaultDisplay();
		if (null != pDisplay)
		{
			pDisplay.getMetrics(pMetrics);

			pDisplay = null;
		}

	}

	private CloudView mCloudV;
}
