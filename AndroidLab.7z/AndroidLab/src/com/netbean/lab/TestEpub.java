package com.netbean.lab;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import nl.siegmann.epublib.domain.Book;
import nl.siegmann.epublib.domain.Resource;
import nl.siegmann.epublib.domain.Resources;
import nl.siegmann.epublib.domain.TOCReference;
import nl.siegmann.epublib.epub.EpubReader;
import android.app.Activity;
import android.content.res.AssetManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.text.method.ScrollingMovementMethod;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.netbean.utils.RegexUtils;

public class TestEpub extends Activity {
	
	private static final String TAG = "epublib";
	
	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		this.setContentView(R.layout.epub);
		
		mEditText = (EditText) this.findViewById(R.id.input);
		mOpenV = (TextView) this.findViewById(R.id.open);
		mOpenV.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v)
			{
				String fileName = mEditText.getText().toString().trim();
				if ((null != fileName) && (fileName.length() > 0))
				{
					InputStream is;
					try
					{
						is = new FileInputStream(fileName);
						openBook(is);
					}
					catch (FileNotFoundException e)
					{
						e.printStackTrace();
					}
				}
			}
		});

		mBookTitleV = (TextView) this.findViewById(R.id.book_title);
		mContentV = (TextView) this.findViewById(R.id.epub_content);

		mImageV = (ImageView) this.findViewById(R.id.image);

		mShowCateV = (TextView) this.findViewById(R.id.epub_cate);
		mShowCateV.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v)
			{
				loadShareDialog();
			}
		});

		mPrevV = (TextView) this.findViewById(R.id.prev);
		mPrevV.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v)
			{
				if (mCurrent > 0)
				{
					mCurrent--;
					loadContent();
				}
				else
				{
					//EpubPage.this.makeToast("already first chapter");
				}
			}
		});

		mNextV = (TextView) this.findViewById(R.id.next);
		mNextV.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v)
			{
				if (mCurrent < mContents.size() - 1)
				{
					mCurrent++;
					loadContent();
				}
				else
				{
					//EpubPage.this.makeToast("already last chapter");
				}
			}
		});

		AssetManager assetManager = this.getAssets();
		InputStream epubInputStream;
		try
		{
			epubInputStream = assetManager.open("books/qq_feb.epub");
			this.openBook(epubInputStream);
		}
		catch (IOException e1)
		{
			e1.printStackTrace();
		}
	}
	
	/**
	 * 
	 * @param is
	 */
	private void openBook(InputStream is)
	{
		try
		{
			mBook = (new EpubReader()).readEpub(is);

			// Log the book's authors
			Log.i(TAG, "author(s): " + mBook.getMetadata().getAuthors());

			// Log the book's title
			Log.i(TAG, "title: " + mBook.getTitle());
			mBookTitleV.setText(mBook.getTitle());

			// Log the book's coverimage property
			Resource resource = mBook.getCoverImage();
			if (null != resource)
			{
				Bitmap coverImage = BitmapFactory.decodeStream(resource.getInputStream());
				Log.i(TAG, "Coverimage is " + coverImage.getWidth() + " by " + coverImage.getHeight() + " pixels");
			}

			// ��ȡĿ¼��Ϣ Log the table of contents
			if (null == mCates)
			{
				mCates = new ArrayList<CateItemInfo>();
			}
			else
			{
				mCates.clear();
			}
			logTableOfContents(mBook.getTableOfContents().getTocReferences(), 0);

			//��ȡ�½����ݺ�ͼƬ��Ϣ
			if (null == mContents)
			{
				mContents = new ArrayList<HtmlItem>();
			}
			else
			{
				mContents.clear();
			}

			// To get all html files that make up the epub file use
			List<Resource> contents = mBook.getContents();
			Log.i(TAG, "content size: " + contents.size());

			for (Resource res : contents)
			{

				// res.getMediaType();
				//
				// Document doc = ResourceUtil.getAsDocument(res);
				// NodeList nodeList = doc.getElementsByTagName("img");
				// if(null !=nodeList)
				// {
				// for (int i = 0; i < nodeList.getLength(); i++)
				// {
				// Node pNode = nodeList.item(i);
				// pNode.getAttributes().
				// }
				// }

				byte[] data = res.getData();
				// html string
				String str = new String(data);
				Log.i(TAG, "content:" + str);

				extractHtml(str);
			}

			mCurrent = 0;
			loadContent();
		}
		catch (Exception e)
		{
			Log.e(TAG, e.getMessage());
			//EpubPage.this.makeToast("�����ˣ�" + e.getMessage());
		}
	}

	private void loadContent()
	{
		if (null != mContents && 0 <= mCurrent && mCurrent < mContents.size())
		{
			mContentV.setText(mContents.get(mCurrent).mTxt);
			mContentV.setMovementMethod(new ScrollingMovementMethod());

			if (null == mContents.get(mCurrent).mBitmap)
			{
				mImageV.setVisibility(View.GONE);
			}
			else
			{
				mImageV.setVisibility(View.VISIBLE);
				mImageV.setImageBitmap(mContents.get(mCurrent).mBitmap);
			}
		}
	}

	// test UI
	/**
	 * method Name:loadShareDialog custom share UI
	 */
	private void loadShareDialog()
	{
//		mDialog = new AppRadioDialog(getContext(), this);
//		mDialog.setCanceledOnTouchOutside(true);
//		mDialog.setProperty(R.string.cates);
//
//		ShareViewAdapter aAdapter = new ShareViewAdapter();
//		mDialog.setRadioSelectListener(aAdapter, aAdapter);
//
//		aAdapter.setData(mCates);
//
//		this.setDialog(mDialog);
//		mDialog.show();
	}

	private class ItemViewHolder {
		TextView mLabel;
	}

	/**
	 * Ŀ¼��
	 * @author junbaozhang
	 *
	 */
	private class CateItemInfo {
		String mLabel;
		String mHref;
	}

	/**
	 * ========================= Function API =========================
	 */
	private Book mBook;
	private TextView mBookTitleV;

	private TextView mOpenV;
	private EditText mEditText;

	// Ŀ¼��Ϣ
	private List<CateItemInfo> mCates;
	private TextView mShowCateV;

	
	private List<HtmlItem> mContents;
	private TextView mContentV;
	
	private ImageView mImageV;
	private int mCurrent = 0;
	private TextView mPrevV;
	private TextView mNextV;

	// �½���Ϣ
	private class HtmlItem {
		 //�½��ı���Ϣ
		String mTxt;
		// �½�ͼƬ��Ϣ
		Bitmap mBitmap;
	}

	/**
	 * ��ȡ�ı���ͼƬ
	 * @param htmlStr
	 * @throws IOException
	 */
	private void extractHtml(String htmlStr) throws IOException
	{
		String result = null;
		String regex = "(?s)<body>(.+?)</body>";
		result = RegexUtils.extract(htmlStr, regex, 1);
		if (null != result)
		{
			HtmlItem item = new HtmlItem();
			List<String> imgSrcs = RegexUtils.getImgStr(result);
			if (null != imgSrcs && imgSrcs.size() > 0)
			{
				for (String imgStr : imgSrcs)
				{
					// filter Image resource ��ȡ�½�ͼƬ��Ϣ FIXME
					Resources resources = mBook.getResources();
					Resource resource = resources.getByHref(imgStr);

					if (null != resource)
					{
						InputStream is = resource.getInputStream();
						Bitmap bitmap = BitmapFactory.decodeStream(is);
						item.mBitmap = bitmap;
						break;
					}
				}
			}
			result = result.replaceAll("<br/>", "\n").replaceAll("<(.*?)>", "").trim();
			if (null != result)
			{
				item.mTxt = result;
			}
			mContents.add(item);
		}
	}

	/**
	 * Recursively Log the Table of Contents
	 * 
	 * @param tocReferences
	 * @param depth
	 */
	private void logTableOfContents(List<TOCReference> tocReferences, int depth)
	{
		if (tocReferences == null)
		{
			return;
		}

		for (TOCReference tocReference : tocReferences)
		{
			StringBuilder tocString = new StringBuilder();
			for (int i = 0; i < depth; i++)
			{
				tocString.append("\t");
			}
			tocString.append(tocReference.getTitle());

			// add chapter item
			CateItemInfo aItem = new CateItemInfo();
			aItem.mLabel = tocReference.getTitle();
			aItem.mHref = tocReference.getCompleteHref();
			mCates.add(aItem);

			Log.i(TAG, tocString.toString());

			logTableOfContents(tocReference.getChildren(), depth + 1);
		}
	}
}
