package com.netbean.lab;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.widget.ImageView;

import com.netbean.view.ScrollScreenLayout;

public class TestScrollPage extends Activity {
	
	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.screens);
		
		mScreenLayout = (ScrollScreenLayout) findViewById(R.id.screens);
		
		LeftImage = (ImageView)findViewById(R.id.left_image);
		LeftImage.setImageResource(R.drawable.froyo);
		
		MidImage = (ImageView) this.findViewById(R.id.mid_image);
		MidImage.setImageResource(R.drawable.gingerbread);
		
		
		RightImage = (ImageView) this.findViewById(R.id.right_image);
		RightImage.setImageResource(R.drawable.honeycomb);
		
//		new Thread(new Runnable() {
//			
//			@Override
//			public void run()
//			{
//				// TODO Auto-generated method stub
//				
//			}
//		});
		
		mHandler = new Handler()
		{
			@Override
			public void handleMessage(Message msg)
			{
				switch(msg.what)
				{
				case KSNAPTOSCREEN:
					mScreenLayout.snapToScreen(1);
					break;
				
				}
			}
		};
		//mHandler.sendMessage(mHandler.obtainMessage(KSNAPTOSCREEN));
		//mHandler.sendMessageDelayed(mHandler.obtainMessage(KSNAPTOSCREEN), 1000);
	}
	
	private static final String TAG = "TestScrollPage";
	public static final int KSNAPTOSCREEN = 1;
	
	private ScrollScreenLayout mScreenLayout;
	private ImageView LeftImage;
	private ImageView MidImage;
	private ImageView RightImage;
	
	private Handler   mHandler;

}
